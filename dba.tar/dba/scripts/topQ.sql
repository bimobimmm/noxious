/*
	This script is used to show top query in DB
	Author: Randy.Pratama@bni.co.id
*/

set lines 175 pages 100
set verify off feed off echo off
col execs for 999,999,999,999
col reads for 999,999,999,999
col gets for 999,999,999,999
col row_process for 999,999,999,999
col cpu_mins for 999,999,999,999
col elap_mins for 999,999,999,999
col sorts for 999,999,999,999
col hour for a4
break on time skip 1
prompt Order by:
prompt 1) Gets
prompt 2) Reads
prompt 3) Exec
prompt 4) Cpu
prompt 5) Elapsed
prompt 6) Row
prompt 7) Sort
accept OrderBy default '1' prompt 'Order by [1]: '
accept day default '0' prompt 'Sysdate - ? : '
select * from (
select to_char(end_interval_time,'dd-mon-yyyy') time, SQL_ID, sum(EXECUTIONS_DELTA) execs,
sum(DISK_READS_DELTA)/decode(sum(EXECUTIONS_DELTA),0,1,sum(EXECUTIONS_DELTA)) reads ,
sum(BUFFER_GETS_DELTA)/decode(sum(EXECUTIONS_DELTA),0,1,sum(EXECUTIONS_DELTA)) gets,
sum(ROWS_PROCESSED_DELTA)/decode(sum(EXECUTIONS_DELTA),0,1,sum(EXECUTIONS_DELTA)) row_process,
(sum(CPU_TIME_DELTA)/decode(sum(EXECUTIONS_DELTA),0,1,sum(EXECUTIONS_DELTA))/1000000/60) cpu_mins,
(sum(ELAPSED_TIME_DELTA)/decode(sum(EXECUTIONS_DELTA),0,1,sum(EXECUTIONS_DELTA))/1000000/60) elap_mins,
sum(SORTS_DELTA)/decode(sum(EXECUTIONS_DELTA),0,1,sum(EXECUTIONS_DELTA)) sorts
from dba_hist_snapshot a, DBA_HIST_SQLSTAT b where b.snap_id = a.snap_id and trunc(a.END_INTERVAL_TIME) = trunc(sysdate-&day)
and EXECUTIONS_DELTA is not null
group by to_char(end_interval_time,'dd-mon-yyyy'), sql_id
 order by decode(nvl('&OrderBy',0),1,gets,2,reads,3,execs,4,cpu_mins,5,elap_mins,6,row_process,7,sorts,gets) desc) where rownum < 11;

accept sqlid prompt 'Details for sql_id: '
select to_char(end_interval_time,'hh24') hour, SQL_ID, sum(EXECUTIONS_DELTA) execs,
sum(DISK_READS_DELTA)/decode(sum(EXECUTIONS_DELTA),0,1,sum(EXECUTIONS_DELTA)) reads ,
sum(BUFFER_GETS_DELTA)/decode(sum(EXECUTIONS_DELTA),0,1,sum(EXECUTIONS_DELTA)) gets,
sum(ROWS_PROCESSED_DELTA)/decode(sum(EXECUTIONS_DELTA),0,1,sum(EXECUTIONS_DELTA)) row_process,
(sum(CPU_TIME_DELTA)/decode(sum(EXECUTIONS_DELTA),0,1,sum(EXECUTIONS_DELTA))/1000000/60) cpu_mins,
(sum(ELAPSED_TIME_DELTA)/decode(sum(EXECUTIONS_DELTA),0,1,sum(EXECUTIONS_DELTA))/1000000/60) elap_mins,
sum(SORTS_DELTA)/decode(sum(EXECUTIONS_DELTA),0,1,sum(EXECUTIONS_DELTA)) sorts
from dba_hist_snapshot a, DBA_HIST_SQLSTAT b where b.snap_id = a.snap_id and trunc(a.END_INTERVAL_TIME) = trunc(sysdate-&&day)
and EXECUTIONS_DELTA is not null and sql_id = '&sqlid'
group by to_char(end_interval_time,'hh24'), sql_id order by 1;

prompt
set long 99999
select sql_text from dba_hist_sqltext where sql_id = '&sqlid';
exit
