set serveroutput on
set lines 125
set pages 1000
set feedback off
set echo off
set ver off
col report_name form a40
col betime form a5
col edtime form a5
col instart_fmt form a20
col snapdat form a20

--ACCEPT snap_date DATE FORMAT 'DDmonYY' DEFAULT '01jan08' PROMPT 'Enter value for snap_date (DDmonYY) : '
ACCEPT num_days PROMPT 'Enter value for num_days : '


select to_char(s.startup_time,'dd Mon "at" HH24:mi:ss')  instart_fmt
     , di.instance_name                                  inst_name
     , di.db_name                                        db_name
     , s.snap_id                                         snap_id
     , to_char(s.end_interval_time,'dd Mon YYYY HH24:mi') snapdat
     , s.snap_level                                      lvl
  from dba_hist_snapshot s
     , dba_hist_database_instance di
     , v$database da
     , v$instance ins
 where s.dbid              = da.dbid
   and di.dbid             = da.dbid
   and s.instance_number   = ins.instance_number
   and di.instance_number  = ins.instance_number
   and ins.instance_number = 1   -- Untuk node ke 1 RAC
   and di.dbid             = s.dbid
   and di.instance_number  = s.instance_number
   and di.startup_time     = s.startup_time
   and s.end_interval_time >= decode( &num_days
                                   , 0   , to_date('31-JAN-9999','DD-MON-YYYY')
                                   , 3.14, s.end_interval_time
                                   , to_date((select to_char(max(end_interval_time),'dd/mm/yyyy')
       from dba_hist_snapshot),'dd/mm/yyyy') - (&num_days-1))
 order by di.db_name, di.instance_name, s.snap_id;

ACCEPT begin_snap CHAR PROMPT 'Enter value for begin_snap : '
ACCEPT end_snap CHAR PROMPT 'Enter value for end_snap   : '

spool awr_genrep.sql

DECLARE
 CURSOR c1 IS
select to_char(s.startup_time,'dd Mon "at" HH24:mi:ss')  instart_fmt
     , di.instance_name                                  inst_name
     , di.db_name                                        db_name
     , s.snap_id                                         snap_id
     , to_char(s.end_interval_time,'dd Mon YYYY HH24:mi') snapdat
     , to_char(s.end_interval_time,'DDmonRR') repdate
     , to_char(s.end_interval_time,'HH24MI') snaphour
     , s.snap_level                                      lvl
  from dba_hist_snapshot s
     , dba_hist_database_instance di
     , v$database da
     , v$instance ins
 where s.dbid              = da.dbid
   and di.dbid             = da.dbid
   and s.instance_number   = ins.instance_number
   and di.instance_number  = ins.instance_number
   and ins.instance_number = 1   -- Untuk node ke 1 RAC
   and di.dbid             = s.dbid
   and di.instance_number  = s.instance_number
   and di.startup_time     = s.startup_time
--   and (to_number(to_char(s.end_interval_time,'MI')) between 0 and 4 or
--        to_number(to_char(s.end_interval_time,'MI')) between 56 and 59)
   and s.end_interval_time >= decode( &num_days
                                   , 0   , to_date('31-JAN-9999','DD-MON-YYYY')
                                   , 3.14, s.end_interval_time
                                   , to_date((select to_char(max(end_interval_time),'dd/mm/yyyy')
       from dba_hist_snapshot),'dd/mm/yyyy') - (&num_days-1))
   and s.snap_id between &begin_snap and &end_snap
 order by di.db_name, di.instance_name, s.snap_id;

    v_report_name varchar2(100);
    v_db_name     varchar2(30);
    v_beid        varchar2(4);
    v_snap_begin  number(8);
    v_snapdate    varchar2(8);
    v number(3) := 1;
BEGIN
    select name into v_db_name from v$database;
    FOR I IN C1 LOOP

      if v > 1 then

        dbms_output.enable(1000000);
        dbms_output.put_line('define num_days='||&num_days);
        dbms_output.put_line('define report_type=text');
        dbms_output.put_line('define begin_snap='||v_snap_begin);
        dbms_output.put_line('define end_snap='||i.snap_id);
        v_report_name:='awr_'||v_snapdate||'_'||v_beid||'-'||i.snaphour||'.txt';
        dbms_output.put_line('define report_name=$HOME/dba/reports/'||v_report_name);
        dbms_output.put_line('@$ORACLE_HOME/rdbms/admin/awrrpt.sql');

      end if;
      v := v + 1;
      v_beid := i.snaphour;
      v_snap_begin := i.snap_id;
      v_snapdate := i.repdate;
    END LOOP;
END;
/


spool off

@awr_genrep.sql

set echo on
set feed on
set ver on

