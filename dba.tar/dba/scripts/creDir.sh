#!/usr/bin/ksh
#******************************************************************
#
#		This script is used to set standard directory
#		Author : Randy.Pratama@bni.co.id
#
#******************************************************************

flag=`cat -n $HOME/dba/.db_profile|grep \`hostname\`|grep -v '/'|head -1|awk '{print $1}'`
down="`cat -n $HOME/dba/.db_profile|grep "\""\/\`hostname\`"\""|tail -1|awk '{print $1}'`"

up=$flag
flag2=`expr $down - $up - 1`
cnt=0

while [ $cnt -lt $flag2 ]
do
cnt=`expr $cnt + 1`
up=`expr $up + 1`
sid=`sed -n "$up,${up}p" $HOME/dba/.db_profile|awk '{print $1}'`

mkdir -p $HOME/dba/logs/${sid}
done


